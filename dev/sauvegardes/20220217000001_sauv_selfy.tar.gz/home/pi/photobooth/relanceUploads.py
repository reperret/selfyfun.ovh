import requests
import os
import json

from datetime import datetime
from tinydb import TinyDB, Query



"""
RESUME :    Récupère la date de création d'un fichier
INPUT  :    chemin absolu du fichier à étudier 
RETURN :    string YYYY-MM-JJ HH:MM:SS
"""
def getDateCreationFile(filename):
    path = os.path.abspath(filename)
    timestamp = os.path.getctime(path)
    date_created = datetime.fromtimestamp(timestamp)
    str_DT = date_created.strftime('%Y-%m-%d %H:%M:%S')
    return str_DT


"""
RESUME :    Envoyer sur le serveur web un fichier
INPUT  :    - filename chemin absolu du fichier à envoyer
            - idEvenement
            - typeImage : 0=>montage, 1=>photo origine 1, 2=> photo origine2, 3=>photo origine 3
            - nomImage : nom du fichier sur le serveur distant
RETURN :    Booléen
"""
def uploadImage(filename,idEvenement,typeImage,nomImage,idImageParent):

    idImage=nomImage
    reponseUpload=False
    nomImageUpload=nomImage
    returnFinal=False
    fileToUpload = filename
    imageToUpload = open(fileToUpload, "rb")
    urlApi = "https://www.selfy.fun/api/api.php"
    params = {
        'idEvenement': idEvenement,
        'idImageParent': idImageParent,
        'nomImage': nomImageUpload,
        'dateCreationImage': getDateCreationFile(fileToUpload),
        'typeImage': typeImage,
        'method': 'uploadImage',
        'auth': 'OHIAZEHRFJIIaeji8949afM'
    }

    try:
        reponseUpload = requests.post(urlApi, files={"image": imageToUpload}, data=params)
        
        
    except requests.ConnectionError as e:
        returnFinal = False
        print("CONNEXION INEXISTANTE")
        print(str(e))
        
    except requests.Timeout as e:
        returnFinal = False
        print("CONNEXION TROP LENTE")
        print(str(e))

    except requests.RequestException as e:
        returnFinal = False
        print("ERREUR GENERALE")
        print(str(e))

    if(reponseUpload != False):
    
        if(reponseUpload.status_code == 200):
            # VERIFICATION COTE SERVEUR
            reponseUploadJson = json.loads(reponseUpload.text)
            
            if (reponseUpload.ok and   reponseUploadJson['ecritureFichierImage'] and  reponseUploadJson['ecritureBddImage'] ):
                print("SUCCESS_UPLOAD_MONTAGE")
                returnFinal=True
            else:
                if (not reponseUpload.ok):
                    print("ERROR_GENERALE_REQUEST")
                if (not reponseUploadJson['ecritureBddImage']):
                    print("ERROR_ECRITURE_BDD")
                if (not reponseUploadJson['ecritureFichierImage']):
                    print("ERROR_ECRITURE_FICHIER")

        elif(reponseUpload.status_code == 404):
            print('ERROR_CONNEXION_INEXISTANTE')
            returnFinal=False
            
    else:
        print('ERROR_CONNEXION_INEXISTANTE')
        returnFinal=False

    return returnFinal,idImage



# CHARGEMENT BDD
db2 = TinyDB('uploads.json')
Sauvegarde = Query()

# RECUPERATION FICHIER EN ERREUR
results = db2.search(Sauvegarde.statutFichier == 0)

print("****************************************************************")
print("    DEBUT RELANCE "+datetime.now().strftime('%d/%m/%Y %H:%M:%S.%fZ') )
print("****************************************************************")

# TRAITEMENT UN PAR UN DES FICHIERS
cpOK=0
cpKO=0
for res in results:
    
    print(datetime.now().strftime('%d/%m/%Y %H:%M:%S.%fZ')+ " ====> Tentative d'envoi fichier "+res['nomFichier']+" du "+res['dateCreationFichier'])
    retourUploadImage=uploadImage(res['cheminFichier'], res['idEvenement'],res['typeFichier'],res['nomFichier'], res['idImageParent'])
    
    if (retourUploadImage[0]):
        cpOK=cpOK+1
        print("Envoi fichier "+res['nomFichier']+" réussi")
        #os.remove(res['cheminFichier'])
        db2.remove(Sauvegarde.cheminFichier == res['cheminFichier'])
    else:
        cpKO=cpKO+1
        print("ECHEC ENVOI fichier :"+res['nomFichier'])
            
    print("\n")


# LOG FINAUX


print("****************************************************************")
print("    FIN RELANCE "+datetime.now().strftime('%d/%m/%Y %H:%M:%S.%fZ'))
print("    Bilan final ==> OK : "+str(cpOK)+" | KO : "+str(cpKO))
print("****************************************************************")

