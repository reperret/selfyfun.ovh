#!/bin/bash
cd /home/pi/photobooth/
detection=$(curl -s https://www.selfy.fun/successConnect.txt)
wifi=1

while [  $wifi == 1 ]
do

	detection=$(curl -s https://www.selfy.fun/successConnect.txt)


	if [[ (  "$detection" == "success" ) ]]
	then
		echo "WIFI OK"
		wifi=0
	else
#		echo "ATTENTE DU WIFI"
		true
	fi
done


sudo python3 camera.py
