import pygame
import requests
import picamera
import time
import os
import PIL.Image
import cups
import RPi.GPIO as GPIO
import qrcode
import io
import base64
import json
import uuid
import subprocess
import threading

from datetime import datetime
from threading import Thread
from pygame.locals import *
from PIL import Image, ImageDraw,ImageColor
from tinydb import TinyDB, Query, where



"""
RESUME :    Enregistre en bdd une trace si l'upload d'une des photos ou du montage a échoué
INPUT  :    chemin absolu du fichier à tracer 
RETURN :    
"""
def logErreurUpload(cheminFichier,idEvenement,typeFichier,nomFichier, idImage):
    db2.insert( {
                'cheminFichier': cheminFichier,
                'statutFichier': 0,
                'dateCreationFichier': datetime.now().strftime("%Y-%m-%d %H:%M:%S") ,
                'idEvenement' : idEvenement,
                'typeFichier' : typeFichier,
                'nomFichier': nomFichier,
                'idImageParent': idImage
                })


"""
RESUME :    Récupère la date de création d'un fichier
INPUT  :    chemin absolu du fichier à étudier 
RETURN :    string YYYY-MM-JJ HH:MM:SS
"""
def getDateCreationFile(filename):
    path = os.path.abspath(filename)
    timestamp = os.path.getctime(path)
    date_created = datetime.fromtimestamp(timestamp)
    str_DT = date_created.strftime('%Y-%m-%d %H:%M:%S')
    return str_DT

"""
RESUME :    Envoyer sur le serveur web un fichier
INPUT  :    - filename chemin absolu du fichier à envoyer
            - idEvenement
            - typeImage : 0=>montage, 1=>photo origine 1, 2=> photo origine2, 3=>photo origine 3
            - nomImage : nom du fichier sur le serveur distant
RETURN :    Booléen
"""
def uploadImage(filename,idEvenement,typeImage,nomImage,idImageParent):

    idImage=nomImage
    reponseUpload=False
    nomImageUpload=nomImage
    returnFinal=False
    fileToUpload = filename
    imageToUpload = open(fileToUpload, "rb")
    urlApi = urlSiteWeb+"/api/api.php"
    params = {
        'idEvenement': idEvenement,
        'idImageParent': idImageParent,
        'nomImage': nomImageUpload,
        'dateCreationImage': getDateCreationFile(fileToUpload),
        'typeImage': typeImage,
        'method': 'uploadImage',
        'auth': 'OHIAZEHRFJIIaeji8949afM'
    }

    try:
        reponseUpload = requests.post(urlApi, files={"image": imageToUpload}, data=params)
        
        
    except requests.ConnectionError as e:
        returnFinal = False
        print("CONNEXION INEXISTANTE")
        print(str(e))
        
    except requests.Timeout as e:
        returnFinal = False
        print("CONNEXION TROP LENTE")
        print(str(e))

    except requests.RequestException as e:
        returnFinal = False
        print("ERREUR GENERALE")
        print(str(e))

    if(reponseUpload != False):
    
        if(reponseUpload.status_code == 200):
            # VERIFICATION COTE SERVEUR
            reponseUploadJson = json.loads(reponseUpload.text)
            
            if (reponseUpload.ok and   reponseUploadJson['ecritureFichierImage'] and  reponseUploadJson['ecritureBddImage'] ):
                print("SUCCESS_UPLOAD_MONTAGE")
                returnFinal=True
            else:
                if (not reponseUpload.ok):
                    print("ERROR_GENERALE_REQUEST")
                if (not reponseUploadJson['ecritureBddImage']):
                    print("ERROR_ECRITURE_BDD")
                if (not reponseUploadJson['ecritureFichierImage']):
                    print("ERROR_ECRITURE_FICHIER")

        elif(reponseUpload.status_code == 404):
            print('ERROR_CONNEXION_INEXISTANTE')
            returnFinal=False
            
    else:
        print('ERROR_CONNEXION_INEXISTANTE')
        returnFinal=False

    return returnFinal,idImage
    #return False,idImage
"""
RESUME :    Récupère dynamiquement les paramètres de l'évènement pour les charger dans le photobooth directement
INPUT  :    urlWebSite : url du domaine de l'API à appeler
RETURN :    
"""
def getConfiguration(urlWebSite):
    try:
        URL = urlWebSite+"/api/api.php"
        PARAMS = {'idAppareil':idAppareil, 'method':'getConfiguration','auth':'OHIAZEHRFJIIaeji8949afM'}
        r = requests.get(url = URL, params = PARAMS, timeout=5)
        data = r.json()

        if(r.status_code == 200):
 
            accueilEvenement = data['accueilEvenement']
            if(accueilEvenement!=""):
                updateParam('accueilEvenement',accueilEvenement)

            templateEvenement = data['templateEvenement']
            if(templateEvenement!=""):
                updateParam('templateEvenement',templateEvenement)

            couleurPrincipaleEvenement = data['couleurPrincipaleEvenement']
            if(couleurPrincipaleEvenement!=""):
                updateParam('couleurPrincipaleEvenement',couleurPrincipaleEvenement)

            couleurSecondaireEvenement = data['couleurSecondaireEvenement']
            if(couleurSecondaireEvenement!=""):
                updateParam('couleurSecondaireEvenement',couleurSecondaireEvenement)
                
            idEvenement = data['idEvenement']
            if(idEvenement!=""):
                updateParam('idEvenement',idEvenement)
                
            reglageRaspistill = data['reglageRaspistill']
            if(reglageRaspistill!=""):
                updateParam('reglageRaspistill',reglageRaspistill)
                
            urlSiteWeb = data['urlSiteWeb']
            if(urlSiteWeb!=""):
                updateParam('urlSiteWeb',urlSiteWeb)

        else:
            print(r.status_code)

    except requests.ConnectionError as e:
        print("[***!***] CONNEXION INTERNET INEXISTANTE\n")
        print(str(e))

    except requests.Timeout as e:
        print("[***!***] CONNEXION TROP LENTE\n")
        print(str(e))

    except requests.RequestException as e:
        print("[***!***] ERREUR GENERALE")
        print(str(e))

"""
RESUME :    Gère les évènements du clavier pour quitter le programme
INPUT  :    events pygame
RETURN :    
"""
def input(events):
    for event in events:
        # presser Echap + Fleche Bas pour quitter le programme
        if (event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE)):
            pygame.quit()

"""
RESUME :    Met à jour l'affichage des écrans
INPUT  :    events pygame
RETURN :    
"""
def updateDisplay():
    # CONNEXION AVEC LES VARIABLES GLOBALES
    global Numeral
    global Message
    global screen
    global background
    global pygame
    global ImageShowed
    global screenPicture
    global backgroundPicture
    global CountDownPhoto
    background.fill(pygame.Color(couleurPrincipaleEvenement))  

    if (Message != ""):
            font = pygame.font.SysFont('quicksandmedium', 60)
            #font = pygame.font.Font(None, 100)
            text = font.render(Message, 1, ImageColor.getcolor(couleurSecondaireEvenement, "RGB"))
            textpos = text.get_rect()
            textpos.centerx = background.get_rect().centerx
            textpos.centery = background.get_rect().centery
            if(ImageShowed):
                    backgroundPicture.blit(text, textpos)
            else:
                    background.blit(text, textpos)

    if (Numeral != ""):
            font = pygame.font.SysFont('quicksandmedium', 600)
            #font = pygame.font.Font(None, 600)
            text = font.render(Numeral, 1, ImageColor.getcolor(couleurSecondaireEvenement, "RGB"))
            textpos = text.get_rect()
            textpos.centerx = background.get_rect().centerx
            textpos.centery = background.get_rect().centery
            if(ImageShowed):
                    backgroundPicture.blit(text, textpos)
            else:
                    background.blit(text, textpos)

    if (CountDownPhoto != ""):
            font = pygame.font.SysFont('quicksandmedium', 300)
            #font = pygame.font.Font(None, 300)
            text = font.render(CountDownPhoto, 1, ImageColor.getcolor(couleurSecondaireEvenement, "RGB"))
            textpos = text.get_rect()
            textpos.centerx = background.get_rect().centerx
            textpos.centery = background.get_rect().centery
            if(ImageShowed):
                    backgroundPicture.blit(text, textpos)
            else:
                    background.blit(text, textpos)
    
    if(ImageShowed == True):
        screenPicture.blit(backgroundPicture, (0, 0))
    else:
        screen.blit(background, (0, 0))
   
    pygame.display.flip()
    return

"""
RESUME :    Détecte le type d'image à afficher pour aiguiller la fonction showPicture
INPUT  :    width & height de l'image en question
RETURN :    1 si on parle des petites photos du bas (position 2 et 3) et 0 sinon
"""
def getshowPictureDisplay(width,height):
    #photo 2 ou 3
    if(width<height):
        return 1
    #photo 1
    else:
        return 0

"""
RESUME :    Affiche à l'écran une image selon son type pendant un laps de temps donné
INPUT  :    chemin absolu du fichier, délai d'affichage, et type d'affichage selon l'image
RETURN :    
"""
def showPicture(file,delay,typeAffichage):
    global pygame
    global screenPicture
    global backgroundPicture
    global ImageShowed
    backgroundPicture.fill(ImageColor.getcolor(couleurPrincipaleEvenement, "RGB"))
    img = pygame.image.load(file)

    #Affichage Photo 2 ou 3
    if(typeAffichage==1):
        img = pygame.transform.scale(img, (int(infoObject.current_h / 1.18 ), infoObject.current_h))  # Make the image full screen
        backgroundPicture.blit(img, (int( (infoObject.current_w-  int(infoObject.current_h / 1.18))/2 )  ,0))
    
    #Affichage photo 1
    elif(typeAffichage==0):
        img = pygame.transform.scale(img, (infoObject.current_w, int(infoObject.current_w / 1.5 )))  # Make the image full screen
        backgroundPicture.blit(img, (0,  int( (infoObject.current_h-int(infoObject.current_w / 1.5 ) ) /2 ) ))
    
    #Affichage montage
    else:
        img = pygame.transform.scale(img, (int(infoObject.current_h / 1.5), infoObject.current_h))  # Make the image full screen
        backgroundPicture.blit(img, (  int( (infoObject.current_w-  int(infoObject.current_h / 1.5))/2 ),0))
    
    screen.blit(backgroundPicture, (0, 0))
    pygame.display.flip()  # update the display
    ImageShowed = True
    time.sleep(delay)

"""
RESUME :    Affiche à l'écran une image selon son type pendant un laps de temps donné
INPUT  :    chemin absolu du fichier, délai d'affichage, et type d'affichage selon l'image
RETURN :    
"""
def showQrCode(image_path):
    screen.fill(pygame.Color(couleurPrincipaleEvenement)) # clear the screen
    img = pygame.image.load(image_path) # load the image
    img = img.convert()
    x = (infoObject.current_w / 2) - (img.get_width() / 2)
    y = (infoObject.current_h / 2) - (img.get_height() / 2)
    screen.blit(img,(x,y))
    pygame.display.flip()

"""
RESUME :    Affiche l'image d'accueil récupérée en base64
INPUT  :    chaine base64
RETURN :    
"""
def showImageHome(imageBase64):
    screen.fill(pygame.Color(couleurPrincipaleEvenement)) # clear the screen
    output = io.BytesIO(base64.b64decode(imageBase64))
    img = pygame.image.load(output) # load the image
    #img = pygame.image.load(image_path) # load the image

    img = img.convert()
    x = (infoObject.current_w / 2) - (img.get_width() / 2)
    y = (infoObject.current_h / 2) - (img.get_height() / 2)
    screen.blit(img,(x,y))
    pygame.display.flip()
    
    
    
def a(width,height,filename):
    if ( width < height ):
        X=int( (infoObject.current_w-  int(infoObject.current_h / 1.18))/2 )
        Y=0
        W=int(infoObject.current_h / 1.18 )
        H=infoObject.current_h
    else:
        X=0
        Y=int( (infoObject.current_h-int(infoObject.current_w / 1.5 ) ) /2 )
        W=infoObject.current_w
        H=int(infoObject.current_w / 1.5 )
        
        
    
    cmd="raspistill -t 4000 -p "+str(X)+","+str(Y)+","+str(W)+","+str(H)+reglageRaspistill+" -op 350 -w "+str(width)+" -h "+str(height)+" -o "+filename
    subprocess.call(cmd,shell=True)
    

def b():
    global Numeral
    global Message
    time.sleep(1)
    for x in range(3, -1, -1):
            if x == 0:                        
                Numeral = ""
                Message = "PRENEZ LA POSE"
            else:                        
                Numeral = str(x)
                Message = ""                
            updateDisplay()
            time.sleep(1)


"""
RESUME :    Processus de capture d'une photo
INPUT  :    on définit la largeur et hauteur de l'image
RETURN :    
"""
def capturePicture(width,height,numPhoto):
    global dossierPhotos
    global Numeral
    global Message
    global screen
    global background
    global screenPicture
    global backgroundPicture
    global pygame
    global ImageShowed
    global CountDownPhoto

    Numeral = ""
    Message = ""
    CountDownPhoto = ""
    updateDisplay()

    background.fill(pygame.Color(couleurPrincipaleEvenement))
    screen.blit(background, (0, 0))
    pygame.display.flip()
    
    
    # CREATION DU FICHIER BIEN NOMME
    tempDate=datetime.now()
    nomPhotoEnCours=tempDate.strftime('%Y%m%d%H%M%S')+"_"+str(numPhoto)+"_"+str(uuid.uuid4())[:8]
    cheminPhotoEnCours = os.path.join(dossierPhotos, 'originaux', nomPhotoEnCours + '.jpg')
    
    # LANCEMENT RASPI
    threading.Thread(target=a, args=(width, height,cheminPhotoEnCours)).start()
    threading.Thread(target=b).start()
    
    time.sleep(6)
    Numeral = ""
    Message = ""
    updateDisplay()

    showPicture(cheminPhotoEnCours, 2, getshowPictureDisplay(width, height))
    ImageShowed = False

    return cheminPhotoEnCours,nomPhotoEnCours

"""
RESUME :    Lance la session complète du photobooth après appui sur bouton poussoir jusqu'à impression
INPUT  :    
RETURN :    
"""
def sessionPhotobooth():
    global dossierPhotos
    global Numeral
    global Message
    global screen
    global background
    global pygame
    global ImageShowed
    global CountDownPhoto
    global Printing
    global TotalMontagesPrinted

    input(pygame.event.get())
    CountDownPhoto = "1/3"
    updateDisplay()
    time.sleep(1)
    returnPhoto1=capturePicture(IMAGE_WIDTH_GRANDE,IMAGE_HEIGHT_GRANDE,1)
    cheminPhoto1=returnPhoto1[0]
    nomPhoto1=returnPhoto1[1]

    CountDownPhoto = "2/3"
    updateDisplay()
    time.sleep(1)
    returnPhoto2=capturePicture(IMAGE_WIDTH_PETITE,IMAGE_HEIGHT_PETITE,2)
    cheminPhoto2=returnPhoto2[0]
    nomPhoto2=returnPhoto2[1]

    CountDownPhoto = "3/3"
    updateDisplay()
    time.sleep(1)
    returnPhoto3=capturePicture(IMAGE_WIDTH_PETITE,IMAGE_HEIGHT_PETITE,3)
    cheminPhoto3=returnPhoto3[0]
    nomPhoto3=returnPhoto3[1]

    CountDownPhoto = ""
    Message = "Veuillez patienter..."
    updateDisplay()
   

    image1 = PIL.Image.open(cheminPhoto1)
    image2 = PIL.Image.open(cheminPhoto2)
    image3 = PIL.Image.open(cheminPhoto3)
    
    # GENERATION NOM FICHIER FINAL
    tempDate=datetime.now()
    nomMontageFinal=tempDate.strftime('%Y%m%d%H%M%S')+"_"+str(uuid.uuid4())[:8]
    
    # INCRUSTATION QRCODE SUR LA PARTIE SUPERIEURE GAUCHE
    qr = qrcode.QRCode(box_size=5)
    qr.add_data(urlSiteWeb + "/photos/" + nomMontageFinal+ ".jpg")
    qr.make()
    img_qr = qr.make_image()
    pos = (870,65)
    bgimage.paste(img_qr, pos)
    
    # ASSEMBLAGE DES IMAGES
    bgimage.paste(image1, (40, 335))
    bgimage.paste(image2, (40, 375+IMAGE_HEIGHT_GRANDE))
    bgimage.paste(image3, (610, 375+IMAGE_HEIGHT_GRANDE))
    
    # ENREGISTREMENT DU FICHIER FINAL
    cheminMontageFinal = os.path.join(dossierPhotos,'montages', nomMontageFinal + ".jpg")
    bgimage.save(cheminMontageFinal)
    showPicture(cheminMontageFinal,3,2)
    ImageShowed = False

    # MISE EN LIGNE DU FICHIER MONTAGE SUR SERVEUR WEB
    retourUploadImage =uploadImage(cheminMontageFinal, idEvenement,0,nomMontageFinal+ ".jpg", None)
    if(not retourUploadImage[0]):
        logErreurUpload(cheminMontageFinal, idEvenement, 0, nomMontageFinal+".jpg",None)

    retourUploadImage1=uploadImage(cheminPhoto1      , idEvenement,1,nomPhoto1      + ".jpg", retourUploadImage[1])
    if(not retourUploadImage1[0]):
        logErreurUpload(cheminPhoto1      , idEvenement,1,nomPhoto1      + ".jpg", retourUploadImage[1])
        
    retourUploadImage2=uploadImage(cheminPhoto2      , idEvenement,2,nomPhoto2      + ".jpg", retourUploadImage[1])
    if(not retourUploadImage2[0]):
        logErreurUpload(cheminPhoto2      , idEvenement,2,nomPhoto2      + ".jpg", retourUploadImage2[1])
        
    retourUploadImage3=uploadImage(cheminPhoto3      , idEvenement,3,nomPhoto3      + ".jpg", retourUploadImage[1])
    if(not retourUploadImage3[0]):
        logErreurUpload(cheminPhoto3      , idEvenement,3,nomPhoto3      + ".jpg", retourUploadImage3[1])
        
        
    time.sleep(1)
    
    #AFFICHAGE DU QRCODE
    Message = "Flashez et retrouvez votre montage"
    updateDisplay()
    time.sleep(2)
    qrcodeImg = qrcode.make(urlSiteWeb+ "/photos/" +nomMontageFinal+ ".jpg")
    type(qrcodeImg)  # qrcode.image.pil.PilImage
    qrcodeImg.save(nomMontageFinal+ "QRCODE.jpg")
    showQrCode(nomMontageFinal+ "QRCODE.jpg")
    time.sleep(7)
    os.remove(nomMontageFinal+ "QRCODE.jpg")

    #PROPOSITION D'IMPRESSION
    Message = "Appuyez sur le bouton pour imprimer"
    updateDisplay()
    time.sleep(2)
    Message = ""
    updateDisplay()
    Printing = False
    waitForPrintingEvent()
    Numeral = ""
    Message = ""
    if Printing:

            if os.path.isfile(absolutePathPhotobooth+ "/photos/montages/"+ nomMontageFinal+ ".jpg"):
                    # Open a connection to cups
                    conn = cups.Connection()
                    # get a list of printers
                    printers = conn.getPrinters()
                    # select printer 0
                    printer_name = "Canon_SELPHY_CP1300"
                    Message = "Impression en cours..."
                    updateDisplay()
                    time.sleep(1)
                    # print the buffer file
                    printqueuelength = len(conn.getJobs())
                    if printqueuelength > 1:
                            showPicture(absolutePathPhotobooth+"/photos/montages/"+ nomMontageFinal+ ".jpg",3,0)
                            conn.enablePrinter(printer_name)
                            Message = "Impression impossible"
                            updateDisplay()
                            time.sleep(1)
                    else:
                            conn.printFile(printer_name, absolutePathPhotobooth+"/photos/montages/"+ nomMontageFinal+ ".jpg", "PhotoBooth", {})
                            TotalMontagesPrinted = TotalMontagesPrinted + 1
                            time.sleep(40)

            
    Message = ""
    Numeral = ""
    ImageShowed = False
    updateDisplay()
    time.sleep(1)

"""
RESUME :    Set à true le booléan Printing pour lancer l'impression suite à impulsion GPIO
INPUT  :    
RETURN :    
"""
def myCallback(channel):
    global Printing
    GPIO.remove_event_detect(BUTTON_PIN)
    Printing=True

"""
RESUME :    Attends l'ordre d'impression par appui bouton poussoir puis lance le compte à rebours
INPUT  :    
RETURN :    
"""
def waitForPrintingEvent():
    global Numeral
    global Message
    global Printing
    global pygame
    countDown = 5
    GPIO.add_event_detect(BUTTON_PIN, GPIO.RISING)
    GPIO.add_event_callback(BUTTON_PIN, myCallback)
    
    while Printing == False and countDown > 0:
        if(Printing == True):
            return
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    GPIO.remove_event_detect(BUTTON_PIN)
                    Printing = True
                    return        

        Numeral = str(countDown)
        Message = ""
        updateDisplay()        
        countDown = countDown - 1
        time.sleep(1)

    GPIO.remove_event_detect(BUTTON_PIN)

"""
RESUME :    
INPUT  :    
RETURN :    
"""
def waitForEvent():
    global pygame
    NotEvent = True
    while NotEvent:
            input_state = GPIO.input(BUTTON_PIN)
            if input_state == False:
                    NotEvent = False
                    return
            for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            pygame.quit()
                        if event.key == pygame.K_DOWN:
                            NotEvent = False
                            return
            time.sleep(0.2)

"""
RESUME :  Insert une valeur dans la base Tiny DB  
INPUT  :  nom du paramètre et sa valeur    
RETURN :    
"""
def insertParam(nomParam,valeurParam):
    db.insert({'param':nomParam,'value':valeurParam})

"""
RESUME :  Récupère une valeur dans la base Tiny DB  
INPUT  :  nom du paramètre   
RETURN :    
"""
def selectParam(nomParam):
    results = db.search(Param.param == nomParam)
    valeurRetour=-1
    for res in results:
        #print(res) # type: tinydb.database.Document
        # print(res.city) # Not allowed!
        valeurRetour=res['value']

    return valeurRetour

"""
RESUME :  Update une valeur dans la base Tiny DB  
INPUT  :  nom du paramètre et sa valeur 
RETURN :    
"""
def updateParam(nomParam,nouvelleValeur):
    db.update({'value':nouvelleValeur},Param.param == nomParam)

"""
RESUME :  Fonction principale lancée du démarrage  
INPUT  :  
RETURN :    
"""
def main(threadName, *args):
    while True:
            showImageHome(accueilEvenement)
            waitForEvent()
            time.sleep(0.2)
            sessionPhotobooth()
    GPIO.cleanup()
    

"""
********************************************************************************************   
********************************************************************************************  
****************************  INITIALISATION DU PROGRAMME***********************************
********************************************************************************************  
********************************************************************************************  
"""

# PREPARATION TINY DB
db = TinyDB('db.json')
Param = Query()

db2 = TinyDB('uploads.json')
Sauvegarde = Query()

# INITIALISATION DES VARIABLES et CONSTANTES
Numeral = ""  # Numeral is the number display
Message = ""  # Message is a fullscreen message
CountDownPhoto = ""
TotalMontagesPrinted = 0  # Compteur du nombre d'impressions
dossierPhotos = 'photos'
absolutePathPhotobooth=os.path.abspath(os.getcwd())
ImageShowed = False
Printing = False
BUTTON_PIN = 25
IMAGE_WIDTH_GRANDE = 1100
IMAGE_HEIGHT_GRANDE = 733
IMAGE_WIDTH_PETITE = 530
IMAGE_HEIGHT_PETITE = 625


# RECUPERATION EN LIGNE DE LA CONFIGURATION DYNAMIQUEMENT
idAppareil=selectParam('idAppareil')
urlSiteWeb = selectParam('urlSiteWeb')
getConfiguration(urlSiteWeb) 
idEvenement=selectParam('idEvenement')
accueilEvenement = selectParam('accueilEvenement')
templateEvenement = selectParam('templateEvenement')
couleurPrincipaleEvenement = selectParam('couleurPrincipaleEvenement')
couleurSecondaireEvenement = selectParam('couleurSecondaireEvenement')
reglageRaspistill = selectParam('reglageRaspistill')
urlSiteWeb = selectParam('urlSiteWeb')


# CHARGEMENT DU TEMPLATE
output = io.BytesIO(base64.b64decode(templateEvenement))
bgimage = PIL.Image.open(output).convert('RGB')


# PARAMETRAGE DU BOUTON POUSSOIR : GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)


# INITIALISATION DE L'INTERFACE GRAPHIQUE
pygame.init()  # Initialise pygame
pygame.mouse.set_visible(False) #cacher la souris
infoObject = pygame.display.Info()

screen = pygame.display.set_mode((infoObject.current_w,infoObject.current_h), pygame.RESIZABLE)  # Full screen 
background = pygame.Surface(screen.get_size())  # créer l'arrière plan
background = background.convert()  # conversion en background

screenPicture = pygame.display.set_mode((infoObject.current_w,infoObject.current_h), pygame.RESIZABLE)  # Full screen
backgroundPicture = pygame.Surface(screenPicture.get_size())  # créer l'arrière plan
backgroundPicture = background.convert()  # conversion en background

transform_x = infoObject.current_w # how wide to scale the jpg when replaying
transfrom_y = infoObject.current_h # how high to scale the jpg when replaying

# LANCEMENT DE LE MATHODE PRINCIPALE
Thread(target=main, args=('Main', 1)).start()

